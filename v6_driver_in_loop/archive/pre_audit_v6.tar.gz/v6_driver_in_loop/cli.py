"""Run a reproducible SIMULATED virtual-driver demonstration."""
import argparse
from pathlib import Path
from .simulation import SimulationEngine,SimulationConfig
from .track import OvalTrack
from .controller import DriverConfig

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--dt',type=float,default=.01); ap.add_argument('--time',type=float,default=180); ap.add_argument('--output',default='v6_output'); ap.add_argument('--laps',type=int,default=1); args=ap.parse_args()
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    result=SimulationEngine(OvalTrack(),driver_config=DriverConfig(),config=SimulationConfig(args.dt,args.time,30,args.laps)).run()
    result.write_csv(out/'simulated_telemetry.csv'); result.write_json(out/'result.json')
    print(f"SIMULATED status={result.status} sim_time={result.elapsed_sim_s:.3f}s lap_time={result.lap_time_s} path_error={result.max_abs_path_error_m:.2f}m wall={result.wall_time_s:.3f}s samples={len(result.samples)}")
    return 0 if result.status=='completed' else 1
if __name__=='__main__': raise SystemExit(main())
