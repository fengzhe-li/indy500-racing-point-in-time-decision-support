"""Compare repeatable driver configurations; outputs include failures."""
import csv
from pathlib import Path
from v6_driver_in_loop import OvalTrack,DriverConfig
from v6_driver_in_loop.simulation import ExperimentRunner,SimulationConfig

configs=[('conservative',DriverConfig(aggression=.82,max_speed_m_s=65)),('baseline',DriverConfig()),('aggressive',DriverConfig(aggression=1.15,max_speed_m_s=82)),('delayed_100ms',DriverConfig(reaction_delay_s=.1))]
rows=ExperimentRunner(track=OvalTrack(),simulation=SimulationConfig(.01,180,30,1)).run(configs)
out=Path('v6_experiments'); out.mkdir(exist_ok=True)
with (out/'experiment_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for row in rows: print(row)
