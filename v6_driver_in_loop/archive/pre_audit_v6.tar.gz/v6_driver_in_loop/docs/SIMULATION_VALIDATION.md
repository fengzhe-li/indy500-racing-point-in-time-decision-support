# Simulation validation and reproducibility

Run from repository root:

```bash
python3 -m unittest discover -s v6_driver_in_loop/tests -v
python3 -m v6_driver_in_loop.cli --dt 0.01 --time 180 --output v6_output
python3 -m v6_driver_in_loop.examples.run_experiments
```

The focused suite exercises positive straight-line acceleration, resistance under zero command, positive yaw response to steering, command saturation/determinism, closed track geometry, telemetry serialization, off-track-capable manual input path, finite timestep refinement, invalid parameters, and experiment reporting. Results must be reported from actual test execution; no performance or lap time is assumed here.

Numerical checks compare one second of the same smooth constant-command case at 20, 10 and 5 ms; these are convergence sanity checks, not a global error bound. Compare output metrics and inspect trajectory/controls before scientific use. Further validation needed for calibrated tire data, combined slip, load transfer, braking distance, lane-change frequency response, and independently surveyed track geometry.

Wall execution time is separately recorded from simulated elapsed time. Benchmark before any real-time statement; the project makes none.
