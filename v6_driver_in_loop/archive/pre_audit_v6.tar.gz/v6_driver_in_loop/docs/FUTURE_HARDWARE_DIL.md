# Future hardware Driver-in-the-Loop

This package provides Software-in-the-Loop only. `HardwareAdapter` is an interface sketch for state acquisition, command output, and shutdown; no device driver, human input device, simulator link, or safety-certified actuator path is implemented.

A future integration needs a measured and timestamped vehicle/simulator state contract, command units and limits, monotonic clock and synchronization, bounded deterministic scheduling, watchdog and stale-data behavior, emergency stop, hardware-in-the-loop bench testing, operator supervision, safe fallback, electrical/mechanical risk assessment, and latency/jitter evidence. Inputs must be validated before actuation. Validate real-time execution under target hardware and load before describing operation as real-time. A manual-input callback is only software input and does not constitute verified human-in-the-loop DIL.
