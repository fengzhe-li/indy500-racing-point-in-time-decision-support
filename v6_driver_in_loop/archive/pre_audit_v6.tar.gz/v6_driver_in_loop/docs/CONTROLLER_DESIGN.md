# Controller design

The lateral controller uses pure pursuit: choose a reference point at `preview_m` ahead of the nearest locally tracked centreline coordinate, calculate body-frame bearing α, then δ=atan(2L sinα/Ld). Steering is saturated to ± the illustrative vehicle steering limit. Optional first-order filtering uses `tau/(tau+dt)`. Track projection is searched locally around prior distance to avoid jumps between parallel oval straights.

The longitudinal controller calculates a desired speed from preview curvature: vref=min(vmax, sqrt(ay_limit/|κ|)), multiplied by aggression. A PID on speed error creates signed effort, separated into throttle or brake and saturated to [0,1]. Integral state is bounded. Optional reaction delay queues prior commands. Gains, preview, limits, and delay are configurable with `DriverConfig`; controllers can be replaced via the simulation loop command interface.

Telemetry stores steering/throttle/brake, lateral and longitudinal acceleration, and signed cross-track error. ExperimentRunner reports status including failures. This is a baseline virtual driver, not an empirical model of human behavior.
