# Proposed V5/V6 integration contract

V6 is independent and imports no V5 module. Integration should occur through neutral typed adapters or serialized data after both feature branches are reviewed.

## Track input

A closed loop exposes `length_m`; a distance coordinate `s_m` in [0,length) with wrapping; samples or segments with `curvature_per_m`; reference `x_m`,`y_m` in a declared local Cartesian coordinate frame; `heading_rad`; `width_m`; optional `banking_rad`. Coordinates are metres, angles radians, curvature inverse metres. Current V6 `TrackPoint` and `OvalTrack.point(s)` follow this shape. Its default geometry is approximate, not official IMS data.

## Vehicle input

SI fields: `mass_kg`, `wheelbase_m`, `yaw_inertia_kg_m2`, axle distances, aerodynamic drag/downforce area products, tire stiffness/friction assumptions, propulsion and braking force limits. Every field should carry provenance (measured, supplied, estimated, illustrative), source/version, and uncertainty where available. V6 defaults are illustrative.

## Outputs

Lap time seconds; distance metres; velocity m/s; acceleration m/s²; heading/yaw radians and radians/s; controls normalized [0,1] and steering radians; metadata with timestep, integration method, controller, track/vehicle provenance, termination status, software version, and explicit SIMULATED label. V6 CSV and JSON use SI quantities and distinguish simulated time from wall-clock duration.

## Comparison

Once both solvers are available, align track geometry and parameter provenance, compare quasi-steady feasible speed/sector estimates against time-domain speed traces and lap aggregates, and explain differences from transients, controller/path tracking, discretization, tire/aero assumptions, and constraints. Do not require numerically identical results: fidelity and purpose differ. Use shared validated inputs but keep each solver's equations and outputs independently auditable. No V5 code is imported here.
