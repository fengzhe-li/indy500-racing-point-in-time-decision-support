# Vehicle dynamics

Coordinates are inertial x/y (m), heading ψ (rad), body longitudinal/lateral velocities u/v (m/s), yaw rate r (rad/s). State evolves as:

- ẋ = u cosψ − v sinψ; ẏ = u sinψ + v cosψ; ψ̇ = r
- u̇ = Fx/m + vr; v̇ = (Fyf+Fyr)/m − ur; ṙ = (lf Fyf − lr Fyr)/Iz
- front/rear slip angles αf = δ − atan2(v+lf r,u), αr = −atan2(v−lr r,u).

Linear axle forces Cα α are clipped independently to ± μFz. Static axle load split is augmented by q·C_LAero, with q=ρ(u²+v²)/2. Drag is q·C_DAero and rolling force is Crr·mg. Longitudinal drive/brake effort is bounded by configured force limits and then clipped to total μ(Fzf+Fzr). This last total-force clipping is a simplification, not a per-wheel combined-slip tire model.

Fixed-step classical RK4 integrates the state under a held command during each step. `dt_s` must be positive and finite. State is checked for finite values and invalid negative forward speed is clamped at zero. Simulation terminates on off-track width exceedance, conservative state limits, lap count, or max simulated time. Near-zero u is regularized to 0.5 m/s in slip calculations; reverse motion is outside the model domain.

Defaults are illustrative: 850 kg, 3.0 m wheelbase, 1200 kg·m² yaw inertia, axle stiffness 90/100 kN/rad, μ=1.5, and simple aero. They are not measured vehicle data.
