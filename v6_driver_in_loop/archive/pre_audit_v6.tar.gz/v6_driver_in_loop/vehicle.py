"""Dynamic single-track vehicle model with linear tires and friction-circle clipping."""
from dataclasses import replace
import math
from .models import VehicleParams,VehicleState,DriverCommand

class VehicleModel:
    def __init__(self,params:VehicleParams|None=None): self.params=params or VehicleParams()
    def derivatives(self,z:VehicleState,cmd:DriverCommand):
        p=self.params; u=max(z.u_m_s,0.5); v=z.v_m_s; r=z.yaw_rate_rad_s; delta=max(-p.max_steer_rad,min(p.max_steer_rad,cmd.steering_rad)); th=max(0.,min(1.,cmd.throttle)); br=max(0.,min(1.,cmd.brake))
        rho=p.air_density_kg_m3; q=.5*rho*(u*u+v*v); down=q*p.downforce_coefficient_area_m2; drag=q*p.drag_coefficient_area_m2
        fzf=p.mass_kg*p.gravity_m_s2*p.lr_m/p.wheelbase_m+down*p.lr_m/p.wheelbase_m; fzr=p.mass_kg*p.gravity_m_s2*p.lf_m/p.wheelbase_m+down*p.lf_m/p.wheelbase_m
        af=delta-math.atan2(v+p.lf_m*r,u); ar=-math.atan2(v-p.lr_m*r,u)
        fyf=max(-p.friction_coefficient*fzf,min(p.friction_coefficient*fzf,p.cornering_front_n_per_rad*af)); fyr=max(-p.friction_coefficient*fzr,min(p.friction_coefficient*fzr,p.cornering_rear_n_per_rad*ar))
        fx=th*p.max_drive_force_n-br*p.max_brake_force_n-drag-p.rolling_resistance*p.mass_kg*p.gravity_m_s2
        # Braking/drive share a combined tire budget; longitudinal demand is clipped.
        limit=p.friction_coefficient*(fzf+fzr); fx=max(-limit,min(limit,fx))
        du=fx/p.mass_kg+v*r; dv=(fyf+fyr)/p.mass_kg-u*r; dr=(p.lf_m*fyf-p.lr_m*fyr)/p.yaw_inertia_kg_m2
        dx=u*math.cos(z.heading_rad)-v*math.sin(z.heading_rad); dy=u*math.sin(z.heading_rad)+v*math.cos(z.heading_rad)
        return (dx,dy,r,du,dv,dr,1.0,math.hypot(dx,dy))
    def step(self,z:VehicleState,cmd:DriverCommand,dt:float)->tuple[VehicleState,float,float]:
        if not math.isfinite(dt) or dt<=0: raise ValueError("dt must be finite and positive")
        # RK4 fixed-step; constant command over step.
        def add(a,k,c): return VehicleState(*(getattr(a,n)+c*dt*kv for n,kv in zip(('x_m','y_m','heading_rad','u_m_s','v_m_s','yaw_rate_rad_s','time_s','distance_m'),k)))
        k1=self.derivatives(z,cmd); k2=self.derivatives(add(z,k1,.5),cmd); k3=self.derivatives(add(z,k2,.5),cmd); k4=self.derivatives(add(z,k3,1),cmd)
        vals=[getattr(z,n)+dt*(a+2*b+2*c+d)/6 for n,a,b,c,d in zip(('x_m','y_m','heading_rad','u_m_s','v_m_s','yaw_rate_rad_s','time_s','distance_m'),k1,k2,k3,k4)]
        out=VehicleState(*vals)
        if out.u_m_s<0: out.u_m_s=0.0
        out.validate(); deriv=self.derivatives(z,cmd); return out,deriv[3],deriv[4]
