"""Closed oval track in local Cartesian coordinates, explicitly approximate."""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class TrackPoint:
    x_m: float; y_m: float; heading_rad: float; curvature_per_m: float; distance_m: float; width_m: float; banking_rad: float = 0.0

class OvalTrack:
    """Two straights plus semicircular ends; no official IMS survey coordinates."""
    def __init__(self, straight_length_m: float=1000.0, radius_m: float=402.336, width_m: float=15.0, banking_rad: float=0.0, samples: int=800):
        if min(straight_length_m,radius_m,width_m) <= 0: raise ValueError("track dimensions must be positive")
        if samples < 20: raise ValueError("samples must be >=20")
        self.straight_length_m=float(straight_length_m); self.radius_m=float(radius_m); self.width_m=float(width_m); self.banking_rad=float(banking_rad); self.samples=samples
        self.length_m=2*self.straight_length_m+2*math.pi*self.radius_m
        self._ds=self.length_m/samples
    def point(self,s:float)->TrackPoint:
        s=float(s)%self.length_m; L=self.straight_length_m; R=self.radius_m
        if s<L: x,y,th,k=s,0.,0.,0.
        elif s<L+math.pi*R:
            q=(s-L)/R; x=L+R*math.sin(q); y=R*(1-math.cos(q)); th=q; k=1/R
        elif s<2*L+math.pi*R:
            q=s-(L+math.pi*R); x=L-q; y=2*R; th=math.pi; k=0.
        else:
            q=(s-(2*L+math.pi*R))/R; x=-R*math.sin(q); y=R+R*math.cos(q); th=math.pi+q; k=1/R
        return TrackPoint(x,y,th,k,s,self.width_m,self.banking_rad)
    def nearest(self,x:float,y:float,around_s:float|None=None,window_m:float=100.0)->TrackPoint:
        # Localized search prevents branch jumps at parallel straight sections.
        if around_s is None: indices=range(self.samples)
        else:
            count=max(10,int(window_m/self._ds)); center=round((around_s%self.length_m)/self._ds); indices=((center+i)%self.samples for i in range(-count,count+1))
        best=None; d2=float('inf')
        for i in indices:
            p=self.point(i*self._ds); z=(p.x_m-x)**2+(p.y_m-y)**2
            if z<d2: best,d2=p,z
        return best
    def target_speed(self,s:float, lateral_accel_limit:float=12.0, max_speed_m_s:float=85.0)->float:
        p=self.point(s); return min(max_speed_m_s, math.sqrt(lateral_accel_limit/abs(p.curvature_per_m)) if p.curvature_per_m else max_speed_m_s)
