# V6 — Driver-in-the-Loop-Ready Vehicle Dynamics Simulation

Self-contained deterministic Software-in-the-Loop simulator with a virtual driver. **All output is simulated**; this is not human-in-the-loop, IndyCar ECU data, a manufacturer validated model, or a real-time certified system.

## Quick start

From the repository root (Python 3.10+; runtime core uses only the standard library):

```bash
python3 -m unittest discover -s v6_driver_in_loop/tests -v
python3 -m v6_driver_in_loop.cli --dt 0.01 --time 180 --output v6_output
python3 -m v6_driver_in_loop.examples.run_experiments
```

The CLI writes `simulated_telemetry.csv` and `result.json`; CSV/JSON include SIMULATED labelling. For plots, install the repository's matplotlib dependency and call `plotting.plot_result(result, 'v6_output/engineering.png')` from Python.

## Architecture

- `models.py`: typed states/commands/results, SI units.
- `vehicle.py`: dynamic bicycle force balance and fixed-step RK4.
- `track.py`: closed-loop, explicitly approximate two-straight/two-semicircle oval; local Cartesian metres, no official survey/GPS claim.
- `controller.py`: localized pure-pursuit lateral control and PID speed control with target speed from preview curvature, optional input filter and reaction delay.
- `simulation.py`: deterministic fixed-step loop, lap/off-track/unstable/timeout termination, telemetry and parameter sweep runner.
- `plotting.py`: optional engineering plot; `hardware.py`: future adapter protocol only.

Default vehicle values are illustrative engineering assumptions, not measured IndyCar parameters. Change them through `VehicleParams`; record provenance before interpreting results.

## Limits

Single-track planar model; linear cornering stiffness with per-axle lateral force saturation; no load transfer, tire transient relaxation, combined-slip friction circle per axle, suspension, drivetrain gears, wind variation, thermal/wear model, or full aero map. Downforce is a simple speed-squared total load increment distributed statically. Track banking is metadata and is not included in force balance. Controller preview intentionally looks ahead by `preview_m` (default 35 m) and speed control uses preview curvature; no global future trajectory is accessed. The simulator reports simulated time and separately measured wall execution time; no real-time claim is made.
