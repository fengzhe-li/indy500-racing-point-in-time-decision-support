"""Interchangeable virtual driver: localized pure-pursuit steering plus speed PID."""
from dataclasses import dataclass
import math
from .models import VehicleState,DriverCommand
from .track import OvalTrack

@dataclass(frozen=True)
class DriverConfig:
    preview_m: float=35.0
    kp_speed: float=0.35
    ki_speed: float=0.025
    kd_speed: float=0.02
    max_speed_m_s: float=75.0
    lateral_accel_limit_m_s2: float=10.0
    reaction_delay_s: float=0.0
    steer_filter_tau_s: float=0.0
    aggression: float=1.0
    def __post_init__(self):
        if self.preview_m<=0 or self.max_speed_m_s<=0 or self.lateral_accel_limit_m_s2<=0 or self.reaction_delay_s<0 or self.steer_filter_tau_s<0 or not (0.2<=self.aggression<=1.5): raise ValueError("invalid driver configuration")

class PurePursuitPIDDriver:
    def __init__(self,track:OvalTrack,config:DriverConfig|None=None):
        self.track=track; self.config=config or DriverConfig(); self.integral=0.; self.prev_error=0.; self.steer=0.; self.delay=[]; self.s=0.
    def command(self,state:VehicleState,dt:float)->tuple[DriverCommand,float]:
        c=self.config; here=self.track.nearest(state.x_m,state.y_m,self.s); self.s=here.distance_m
        target=self.track.point(here.distance_m+c.preview_m); dx=target.x_m-state.x_m; dy=target.y_m-state.y_m
        alpha=math.atan2(-math.sin(state.heading_rad)*dx+math.cos(state.heading_rad)*dy,math.cos(state.heading_rad)*dx+math.sin(state.heading_rad)*dy)
        steer=math.atan2(2*3.0*math.sin(alpha),max(1.,c.preview_m)); steer=max(-math.radians(18),min(math.radians(18),steer))
        if c.steer_filter_tau_s>0: self.steer+=(dt/(c.steer_filter_tau_s+dt))*(steer-self.steer)
        else: self.steer=steer
        target_speed=min(c.max_speed_m_s,self.track.target_speed(here.distance_m+c.preview_m,c.lateral_accel_limit_m_s2,c.max_speed_m_s))*c.aggression
        err=target_speed-state.u_m_s; self.integral=max(-20.,min(20.,self.integral+err*dt)); der=(err-self.prev_error)/dt if dt else 0.; self.prev_error=err
        effort=c.kp_speed*err+c.ki_speed*self.integral+c.kd_speed*der; throttle=max(0.,min(1.,effort/5.)); brake=max(0.,min(1.,-effort/8.))
        self.delay.append(DriverCommand(self.steer,throttle,brake)); delay_steps=round(c.reaction_delay_s/dt) if dt else 0
        out=self.delay.pop(0) if len(self.delay)>delay_steps else DriverCommand(0.,0.,0.)
        return out, (state.x_m-here.x_m)*(-math.sin(here.heading_rad))+(state.y_m-here.y_m)*math.cos(here.heading_rad)
