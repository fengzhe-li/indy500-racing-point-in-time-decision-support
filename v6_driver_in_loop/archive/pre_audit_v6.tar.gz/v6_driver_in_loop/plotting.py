"""Optional engineering plot from SIMULATED telemetry; requires matplotlib."""
def plot_result(result,path):
    import matplotlib.pyplot as plt
    t=[s.sim_time_s for s in result.samples]
    fig,ax=plt.subplots(2,2,figsize=(11,8)); ax[0,0].plot([s.x_m for s in result.samples],[s.y_m for s in result.samples]); ax[0,0].set_title('SIMULATED trajectory'); ax[0,0].set_aspect('equal')
    ax[0,1].plot(t,[s.u_m_s for s in result.samples]); ax[0,1].set_title('Speed (m/s)')
    ax[1,0].plot(t,[s.steering_command_rad for s in result.samples],label='steer'); ax[1,0].plot(t,[s.throttle_command for s in result.samples],label='throttle'); ax[1,0].plot(t,[s.brake_command for s in result.samples],label='brake'); ax[1,0].legend(); ax[1,0].set_title('Driver inputs')
    ax[1,1].plot(t,[s.yaw_rate_rad_s for s in result.samples],label='yaw rate'); ax[1,1].plot(t,[s.lateral_accel_m_s2 for s in result.samples],label='lateral accel'); ax[1,1].legend(); ax[1,1].set_title('Vehicle response')
    fig.tight_layout(); fig.savefig(path,dpi=150); plt.close(fig)
