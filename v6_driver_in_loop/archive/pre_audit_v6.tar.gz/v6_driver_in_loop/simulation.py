"""Deterministic fixed-step SI simulation, telemetry, and experiment runner."""
from dataclasses import dataclass,asdict
import csv,json,math,time
from pathlib import Path
from .models import VehicleState,TelemetrySample,DriverCommand
from .vehicle import VehicleModel
from .track import OvalTrack
from .controller import PurePursuitPIDDriver,DriverConfig

@dataclass(frozen=True)
class SimulationConfig:
    dt_s: float=.01
    max_time_s: float=180.
    start_speed_m_s: float=30.
    max_laps: int=1
    def __post_init__(self):
        if not math.isfinite(self.dt_s) or self.dt_s<=0 or not math.isfinite(self.max_time_s) or self.max_time_s<=0 or self.start_speed_m_s<0 or self.max_laps<1: raise ValueError("invalid simulation configuration")

@dataclass
class SimulationResult:
    status:str; lap_time_s:float|None; elapsed_sim_s:float; wall_time_s:float; samples:list[TelemetrySample]; off_track:bool; max_abs_path_error_m:float; reason:str=''
    def write_csv(self,path):
        if not self.samples: return
        with open(path,'w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(asdict(self.samples[0]).keys())); w.writeheader(); w.writerows(asdict(s) for s in self.samples)
    def write_json(self,path):
        Path(path).write_text(json.dumps({'label':'SIMULATED','status':self.status,'lap_time_s':self.lap_time_s,'elapsed_sim_s':self.elapsed_sim_s,'wall_time_s':self.wall_time_s,'off_track':self.off_track,'max_abs_path_error_m':self.max_abs_path_error_m,'reason':self.reason,'samples':[asdict(s) for s in self.samples]},indent=2))

class SimulationEngine:
    def __init__(self,track:OvalTrack|None=None,vehicle:VehicleModel|None=None,driver_config:DriverConfig|None=None,config:SimulationConfig|None=None):
        self.track=track or OvalTrack(); self.vehicle=vehicle or VehicleModel(); self.driver_config=driver_config or DriverConfig(); self.config=config or SimulationConfig()
    def run(self, initial_state:VehicleState|None=None, manual_input=None)->SimulationResult:
        cfg=self.config; state=initial_state or VehicleState(x_m=0,y_m=0,heading_rad=0,u_m_s=cfg.start_speed_m_s); state.validate(); driver=PurePursuitPIDDriver(self.track,self.driver_config); samples=[]; start=time.perf_counter(); off=False; maxerr=0.; lap_time=None; reason='maximum simulated time reached'; status='timeout'; prev_s=0.; wraps=0
        n=math.ceil(cfg.max_time_s/cfg.dt_s)
        for _ in range(n):
            p=self.track.nearest(state.x_m,state.y_m,driver.s); s=p.distance_m
            if s+0.5*self.track.length_m<prev_s: wraps+=1
            prev_s=s
            if wraps>=cfg.max_laps: status='completed'; lap_time=state.time_s; reason='lap completion'; break
            cmd,err=driver.command(state,cfg.dt_s) if manual_input is None else (manual_input(state),0.)
            maxerr=max(maxerr,abs(err)); sample_a=self.vehicle.derivatives(state,cmd); next_state,ax,ay=self.vehicle.step(state,cmd,cfg.dt_s); pnext=self.track.nearest(next_state.x_m,next_state.y_m,s); off=math.hypot(next_state.x_m-pnext.x_m,next_state.y_m-pnext.y_m)>pnext.width_m/2
            samples.append(TelemetrySample(state.time_s,state.x_m,state.y_m,state.heading_rad,state.u_m_s,state.v_m_s,state.yaw_rate_rad_s,cmd.steering_rad,cmd.throttle,cmd.brake, state.u_m_s*state.yaw_rate_rad_s,ax,err,state.distance_m))
            state=next_state
            if off: status='off_track'; reason='track boundary exceeded'; break
            if abs(state.v_m_s)>100 or abs(state.yaw_rate_rad_s)>10: status='unstable'; reason='state limit exceeded'; break
        return SimulationResult(status,lap_time,state.time_s,time.perf_counter()-start,samples,off,maxerr,reason)

class ExperimentRunner:
    def __init__(self,track=None,vehicle=None,simulation=None): self.track=track or OvalTrack(); self.vehicle=vehicle or VehicleModel(); self.simulation=simulation or SimulationConfig()
    def run(self,configs):
        rows=[]
        for name,driver_cfg in configs:
            result=SimulationEngine(self.track,self.vehicle,driver_cfg,self.simulation).run()
            rows.append({'name':name,'status':result.status,'lap_time_s':result.lap_time_s,'max_path_error_m':result.max_abs_path_error_m,'off_track':result.off_track,'wall_time_s':result.wall_time_s,'reason':result.reason})
        return rows
