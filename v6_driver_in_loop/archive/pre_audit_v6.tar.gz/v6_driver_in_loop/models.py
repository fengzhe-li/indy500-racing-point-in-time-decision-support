"""Typed SI interfaces. Coordinates are inertial x east, y north; angles rad."""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class VehicleParams:
    mass_kg: float = 850.0
    wheelbase_m: float = 3.0
    yaw_inertia_kg_m2: float = 1200.0
    lf_m: float = 1.35
    lr_m: float = 1.65
    cornering_front_n_per_rad: float = 90000.0
    cornering_rear_n_per_rad: float = 100000.0
    friction_coefficient: float = 1.5
    max_steer_rad: float = math.radians(18)
    max_drive_force_n: float = 9000.0
    max_brake_force_n: float = 18000.0
    drag_coefficient_area_m2: float = 1.2
    air_density_kg_m3: float = 1.225
    rolling_resistance: float = 0.015
    downforce_coefficient_area_m2: float = 3.0
    gravity_m_s2: float = 9.80665
    def __post_init__(self):
        positive = (self.mass_kg, self.wheelbase_m, self.yaw_inertia_kg_m2, self.lf_m, self.lr_m, self.cornering_front_n_per_rad, self.cornering_rear_n_per_rad, self.friction_coefficient, self.max_steer_rad, self.max_drive_force_n, self.max_brake_force_n, self.air_density_kg_m3, self.gravity_m_s2)
        if any(not math.isfinite(x) or x <= 0 for x in positive): raise ValueError("vehicle parameters must be finite and positive")
        if self.drag_coefficient_area_m2 < 0 or self.downforce_coefficient_area_m2 < 0 or self.rolling_resistance < 0: raise ValueError("resistance/aero parameters cannot be negative")
        if abs(self.lf_m + self.lr_m - self.wheelbase_m) > 1e-6: raise ValueError("lf + lr must equal wheelbase")

@dataclass
class VehicleState:
    x_m: float = 0.0
    y_m: float = 0.0
    heading_rad: float = 0.0
    u_m_s: float = 30.0
    v_m_s: float = 0.0
    yaw_rate_rad_s: float = 0.0
    time_s: float = 0.0
    distance_m: float = 0.0
    def validate(self):
        vals=(self.x_m,self.y_m,self.heading_rad,self.u_m_s,self.v_m_s,self.yaw_rate_rad_s,self.time_s,self.distance_m)
        if not all(math.isfinite(v) for v in vals): raise FloatingPointError("non-finite vehicle state")
        if self.u_m_s < -0.1 or self.time_s < 0 or self.distance_m < 0: raise FloatingPointError("invalid vehicle state")

@dataclass(frozen=True)
class DriverCommand:
    steering_rad: float
    throttle: float
    brake: float

@dataclass(frozen=True)
class TelemetrySample:
    sim_time_s: float; x_m: float; y_m: float; heading_rad: float
    u_m_s: float; v_m_s: float; yaw_rate_rad_s: float
    steering_command_rad: float; throttle_command: float; brake_command: float
    lateral_accel_m_s2: float; longitudinal_accel_m_s2: float
    path_error_m: float; distance_m: float; simulated: bool = True
